export default async function handler(req, res) {
  const TOKEN = process.env.KASPI_TOKEN || 'n2dEWgSNwnqnHv+7X8wISJQYe8qMzC6fzghaRiLDg/k=';
  const BASE = 'https://kaspi.kz/shop/api/v2';
  const { state = 'NEW', page = 0, size = 100 } = req.query;

  try {
    const r = await fetch(
      `${BASE}/orders?page[number]=${page}&page[size]=${size}&filter[orders][state]=${state}`,
      {
        headers: {
          'X-Auth-Token': TOKEN,
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      }
    );
    const data = await r.json();
    res.setHeader('Cache-Control', 's-maxage=60');
    res.status(200).json(data);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}
