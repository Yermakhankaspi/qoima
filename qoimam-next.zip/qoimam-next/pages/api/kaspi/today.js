export default async function handler(req, res) {
  const TOKEN = process.env.KASPI_TOKEN || 'n2dEWgSNwnqnHv+7X8wISJQYe8qMzC6fzghaRiLDg/k=';
  const BASE = 'https://kaspi.kz/shop/api/v2';
  const headers = {
    'X-Auth-Token': TOKEN,
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  };

  const states = ['NEW', 'PROCESSING', 'COMPLETED', 'CANCELLED'];
  const results = {};

  await Promise.all(
    states.map(async (state) => {
      try {
        const r = await fetch(
          `${BASE}/orders?page[number]=0&page[size]=100&filter[orders][state]=${state}`,
          { headers }
        );
        results[state] = await r.json();
      } catch (e) {
        results[state] = { error: e.message, data: [] };
      }
    })
  );

  res.setHeader('Cache-Control', 's-maxage=60');
  res.status(200).json(results);
}
